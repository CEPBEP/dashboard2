# PHP7_login
Really simple login and register system in PHP 7. Secured with PDO and hashed password. To install it on your MySQL server run install.sql. It is designed to work on localhost, root, account, no password, because it was tested on XAMPP. You can easily change it in connect.php. In restore branch you have version with password restore, which have to use mail server and requiers a few changes in php.ini. Everything is described in install/instruction.txt
To download version with password restore write:
git clone -b restore https://github.com/T3chnoMaciej/PHP7_login.git
