<?php
   function dbConnect(){
     try {
       $conn = new PDO ("mysql:dbname=id2000862_paym;host=localhost", "id2000862_root", "63qwerty");
       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return $conn;
     } catch (PDOException $e) {
       echo 'ERROR', $e->getMessage();
     }

   }
?>